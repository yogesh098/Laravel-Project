<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
.container {
  background-color: #6495ED;
}
</style>
</head>

<body >
<div class = "container">
<div class="row">
        <div class="col-md-6">
            <br>
        </div>
    <div class="col-md-6">
        <br>
    </div>

    </div>
<!-- <div class="p-3 mb-2 bg-primary text-white"> -->

<div class = "row">
<div class = "col-md-4">
<div class="panel panel-default">
    <div class="panel-body">
<h2> BOOK</h2>
<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(url('products/'.$product->getId())); ?>"></a>


<b><?php echo e($product->getTitle()); ?></b></br>


<?php echo e($product->getFirstName()); ?>


<?php echo e($product->getMainName()); ?></br>
<?php echo e($product->getPrice()); ?></br>

No. of pages :<?php echo e($product->getNumberofPages()); ?></br>
</br>

<button><a href="<?php echo e(url('products/'.$product->getId())); ?>">Select</a></button>


<!-- <form method="POST" action="/products">
<?php echo csrf_field(); ?>
<?php echo method_field('select'); ?>
<button class="select product" value="<?php echo e($product->getId()); ?>">Select</button>
</form> -->
<br>
<br>
<br>
<br>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>

<div class = "col-md-4">
<div class="panel panel-default">
    <div class="panel-body">

<h2> CD</h2>
<?php $__currentLoopData = $cds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(url('products/'.$product->getId())); ?>"></a>


<strong><?php echo e($product->getTitle()); ?></strong></br>

<?php echo e($product->getFirstName()); ?>

<?php echo e($product->getMainName()); ?></br>

<?php echo e($product->getPrice()); ?></br>

Playlength:<?php echo e($product->getPlayLength()); ?></br>
</br>
 
<button><a href="<?php echo e(url('products/'.$product->getId())); ?>">Select</a></button>


<!-- <form method="POST" action="/products">
<?php echo csrf_field(); ?>
<?php echo method_field('select'); ?>
<button class="select product" value="<?php echo e($product->getId()); ?>">Select</button>
</form> -->
<br>
<br>
<br>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>

<div class = "col-md-4">
<div class="panel panel-default">
    <div class="panel-body">
 <form action="<?php echo e(url('products/store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <b><h2>Product Type : </h2></b>
  <select name ="type">
  <b><option value = "cd" > CD </option></b>
  <b><option value = "book" > Book </option></b>
  </select><br/>
  <input type = "text" name = "title" placeholder ="Title" required ><br/>
  <input type = "text" name = "firstname" placeholder ="firstname (optional)"  ><br/>
  <input type = "text" name = "surname" placeholder ="surname/band"  ><br/>
  <input type = "text" name = "price" placeholder ="price"  ><br/>
  <input type = "text" name = "papl" placeholder ="pages/play length"  ><br/>

  <button type = "submit" name = "save" class = "btn-success" > Add new </button>

  </form>
  
  </div>
</div>
</div>
  </div>
</div>
</div>
  </body>
  </html><?php /**PATH C:\xampp\htdocs\yog\blog\resources\views/products.blade.php ENDPATH**/ ?>

<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
.container {
  background-color: #6495ED;
}
</style>
</head>

<body >
<div class = "container">
<div class="row">
	<h2>Update And delete</h2>
<div class = "col-md-4">
<div class="panel panel-default">
    <div class="panel-body">

<?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <form action="<?php echo e(url('products/update/'.$products -> getId ())); ?>" method="POST">
 
  <b>Product Type : <input type="text" name="" value="<?php echo e($products -> getId ()); ?>"></h2></b>

  <br/>
  <input type = "text" name = "title" placeholder ="Title" value="<?php echo e($products -> getTitle ()); ?>" ><br/>
  <input type = "text" name = "firstname" placeholder ="firstname (optional)"  value="<?php echo e($products -> getTitle ()); ?>" ><br/>
  <input type = "text" name = "surname" placeholder ="surname/band" value="<?php echo e($products -> getMainName ()); ?>"  ><br/>
  <input type = "text" name = "price" placeholder ="price" value="<?php echo e($products -> getPrice ()); ?>"   ><br/>
  <input type = "text" name = "papl" placeholder ="pages/play length" value="<?php echo e($products -> getPlayLength ()); ?>"  ><br/>

  <button type = "submit" name = "update" class = "btn btn-success" > Update </button> <a href="<?php echo e(url('delete/'.$products->getId())); ?>" class="btn btn-danger">Delete </a>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\yog\blog\resources\views/singleCd.blade.php ENDPATH**/ ?>